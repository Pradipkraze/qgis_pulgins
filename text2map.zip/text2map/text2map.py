# -*- coding: utf-8 -*-
"""
Text2Map – Main Plugin Class
QGIS 4 / Qt6 compatible.

Key Qt6 changes applied:
  - All imports use qgis.PyQt shim (never direct PyQt5/PyQt6)
  - Qt enum values are fully qualified: Qt.DockWidgetArea.RightDockWidgetArea
"""

import os

from qgis.PyQt.QtWidgets import QAction, QDockWidget
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt

from .text2map_dockwidget import Text2MapDockWidget


class Text2Map:
    """QGIS Plugin Implementation – QGIS 4 / Qt6."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.dock_widget = None
        self.action = None

    def initGui(self):
        """Create toolbar icon and menu entry."""
        icon_path = os.path.join(self.plugin_dir, 'icons', 'icon.png')
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, 'Text2Map', self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.setToolTip('Text2Map – Convert pasted text to geometry layers')
        self.action.triggered.connect(self.toggle_panel)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu('&Text2Map', self.action)

    def toggle_panel(self, checked):
        """Show/hide the dock widget."""
        if self.dock_widget is None:
            self.dock_widget = Text2MapDockWidget(self.iface)
            # Qt6: enum values are fully qualified
            self.dock_widget.setAllowedAreas(
                Qt.DockWidgetArea.LeftDockWidgetArea |
                Qt.DockWidgetArea.RightDockWidgetArea
            )
            self.iface.addDockWidget(
                Qt.DockWidgetArea.RightDockWidgetArea,
                self.dock_widget
            )
            self.dock_widget.visibilityChanged.connect(self._on_visibility_changed)

        if checked:
            self.dock_widget.show()
        else:
            self.dock_widget.hide()

    def _on_visibility_changed(self, visible):
        self.action.setChecked(visible)

    def unload(self):
        """Remove plugin from QGIS GUI."""
        self.iface.removePluginMenu('&Text2Map', self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.dock_widget is not None:
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget.deleteLater()
            self.dock_widget = None
