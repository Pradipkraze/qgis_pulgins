# Changelog

## [2.0.0] – 2024-01-01  — QGIS 4 / Qt6

### Changed (QGIS 4 / Qt6 migration)
- All imports switched to `qgis.PyQt` shim — direct `PyQt5` / `PyQt6` imports removed
- Qt enum values fully qualified throughout (e.g. `Qt.AlignmentFlag.AlignCenter`,
  `Qt.DockWidgetArea.RightDockWidgetArea`, `QFrame.Shape.HLine`, `QFrame.Shadow.Sunken`,
  `QSizePolicy.Policy.Expanding`, `QgsWkbTypes.GeometryType.PointGeometry`)
- `QVariant` removed from `QgsField` construction — replaced with Python type strings
  (`'string'`, `'integer'`, `'double'`)
- `qgisMinimumVersion` set to `4.0`, `qgisMaximumVersion` set to `4.99`

## [1.0.0] – Initial release (QGIS 3.x)
- Decimal lat/lon, DMS, JSON, GeoJSON, WKT support
- Auto format detection, memory layer creation, attribute preservation
