# -*- coding: utf-8 -*-
"""
Text2Map QGIS Plugin
Convert text-based spatial data (lat/lon, JSON, GeoJSON, WKT) to map layers.
Requires QGIS 4.0+ (Qt6 / PyQt6 via qgis.PyQt shim).
"""


def classFactory(iface):
    """Load Text2Map class from file text2map.py"""
    from .text2map import Text2Map
    return Text2Map(iface)
