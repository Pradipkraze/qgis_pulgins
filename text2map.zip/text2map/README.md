# Text2Map – QGIS 4 Plugin

**Convert pasted text into map geometry layers — instantly.**

Text2Map adds a side panel to QGIS where you paste spatial data in any common text format and click **Create Layer** to visualise it on the map.

> **QGIS 4 / Qt6 only.** For QGIS 3.x, use version 1.x.

---

## Supported Input Formats

| Format | Example |
|---|---|
| Decimal lat/lon | `28.6139, 77.2090` |
| Multi-line lat/lon | One pair per line → multiple points |
| DMS | `28°36'50"N 77°12'32"E` |
| JSON object | `{"lat": 28.61, "lon": 77.20, "name": "Delhi"}` |
| JSON array | `[{"latitude":..., "longitude":...}, ...]` |
| GeoJSON | FeatureCollection / Feature / bare geometry |
| WKT | `POINT(77.209 28.613)`, `LINESTRING(...)`, `POLYGON(...)` |

---

## Installation

### QGIS Plugin Repository
1. **Plugins → Manage and Install Plugins…**
2. Search **Text2Map**
3. Click **Install Plugin**

### Manual (ZIP)
1. Download `text2map.zip` from the [Releases](https://github.com/yourusername/text2map/releases) page.
2. **Plugins → Manage and Install Plugins… → Install from ZIP**

---

## Usage

1. Click the **Text2Map** toolbar button (or **Plugins → Text2Map → Text2Map**).
2. Paste your data into the text area.
3. Optionally change the layer name.
4. Click **Create Layer**.

A new memory layer appears in the Layers panel and the map zooms to it.

---

## Input Format Examples

### Decimal Lat/Lon
```
28.6139, 77.2090
12.9716, 77.5946
19.0760, 72.8777
```

### DMS
```
28°36'50"N 77°12'32"E
```

### JSON Array
```json
[
  {"lat": 28.6139, "lon": 77.2090, "city": "Delhi"},
  {"lat": 12.9716, "lon": 77.5946, "city": "Bengaluru"}
]
```

### GeoJSON
```json
{
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {"type": "Point", "coordinates": [77.2090, 28.6139]},
      "properties": {"name": "Delhi"}
    }
  ]
}
```

### WKT (one geometry per line)
```
POINT(77.2090 28.6139)
LINESTRING(77.2090 28.6139, 77.5946 12.9716)
POLYGON((77.0 28.0, 78.0 28.0, 78.0 29.0, 77.0 29.0, 77.0 28.0))
```

---

## Requirements

- **QGIS 4.0+** (Qt6 build)
- No additional Python packages required

---

## QGIS 4 / Qt6 Migration Notes

This version targets QGIS 4 exclusively and includes these Qt6 changes:

- All Qt imports use the `qgis.PyQt` shim (`qgis.PyQt.QtWidgets`, etc.)
- Qt enum values are fully qualified (`Qt.AlignmentFlag.AlignCenter`, `Qt.DockWidgetArea.RightDockWidgetArea`, etc.)
- `QVariant` removed — `QgsField` now accepts Python type strings (`'string'`, `'integer'`, `'double'`)
- `QFrame.Shape` / `QFrame.Shadow` enums fully qualified

---

## License

[GNU General Public License v2.0](LICENSE)
